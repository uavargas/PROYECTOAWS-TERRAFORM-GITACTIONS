import json
import boto3
import os
import time

def lambda_handler(event, context):
    # 1. Conectamos con los servicios usando variables de entorno de Terraform
    dynamodb = boto3.resource('dynamodb')
    table = dynamodb.Table(os.environ['TABLE_NAME'])
    sns = boto3.client('sns')
    
    # 2. Extraemos los datos que vienen del Frontend (vía API Gateway)
    body = json.loads(event['body'])
    user_id = body['userId']
    score = body['score']
    timestamp = int(time.time())
    
    # 3. Guardamos en DynamoDB
    table.put_item(Item={
        'UserId': user_id,
        'Timestamp': timestamp,
        'Score': score
    })
    
    # 4. Enviamos notificación por SNS
    message = f"¡ El usuario {user_id} ha obtenido {score} puntos."
    sns.publish(
        TopicArn=os.environ['SNS_TOPIC_ARN'],
        Message=message,
        Subject="Nuevo usuario ha realizado el test de CodeQuiz"
    )
    
    return {
        'statusCode': 200,
        'headers': {'Access-Control-Allow-Origin': '*'},
        'body': json.dumps({'message': 'Puntaje guardado!'})
    }